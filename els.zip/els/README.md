
# Equipment Loan System

A simple equipment loan system built using PHP, Bootstraps and SQL. It is created to solved issue on irresponsible equipment loan, and equipment tracking for asset management.

Stack
# Stack
This system is developed using Bootstraps, mysql and php.

## Setup

You only need to import a sql file name **els.sql** to your database. To create an admin, use link **<dummy-domain/creator.php**
The dummy domain can be **localhost** if you are using **xampp** or **equipment-loan-system.test** if you are using **laragon**
