<aside class="left-sidebar" data-sidebarbg="skin5">
	<!-- Sidebar scroll-->
	<div class="scroll-sidebar">
		<!-- Sidebar navigation-->
		<nav class="sidebar-nav">
			<ul id="sidebarnav" class="p-t-30">
				<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
				<li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-account-box"></i><span class="hide-menu">Administrator </span></a>
					<ul aria-expanded="false" class="collapse  first-level">
						<li class="sidebar-item">
							<a href="admins.php" class="sidebar-link"><i class="mdi mdi-account-multiple"></i><span class="hide-menu">Manage Admins</span></a>
						</li>
						<li class="sidebar-item">
							<a href="departments.php" class="sidebar-link"><i class="mdi mdi-home-modern"></i><span class="hide-menu"> Departments</span></a>
						</li>
						<li class="sidebar-item">
							<a href="logs.php" class="sidebar-link"><i class="mdi mdi-format-align-justify"></i><span class="hide-menu"> Log</span></a>
						</li>
					</ul>
				</li>
				<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="tools.php" aria-expanded="false"><i class="mdi mdi-tooltip"></i><span class="hide-menu">Tools</span></a></li>
				<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="users.php" aria-expanded="false"><i class="mdi mdi-account-outline"></i><span class="hide-menu">Users</span></a></li>
			</ul>
		</nav>
		<!-- End Sidebar navigation -->
	</div>
	<!-- End Sidebar scroll-->
</aside>