<footer class="footer text-center">
    All Rights Reserved by Skyrem Brilliant Services. Designed and Developed by <a href="https://www.linkedin.com/in/rasyidialwee">Rasyidi Alwee</a>.
</footer>